DEEKsha & ABHISHEK — WEDDING INVITATION WEBSITE
================================================

Files
- index.html: responsive bilingual wedding invitation website
- assets/wedding-melody.wav: original synthesized instrumental loop used by the music button

Event details currently set
- Deeksha & Abhishek
- 17 November 2026, 8:00 PM (India time)
- Shubham Highway Treat & Resort, Guna, Madhya Pradesh

To preview
1. Extract the ZIP.
2. Open index.html in a browser. Some browser security features may behave differently from a hosted HTTPS site.

FREE HOSTING OPTION A — Vercel
1. Go to https://vercel.com and sign in.
2. Create a new project and import a GitHub repository containing these files, OR use Vercel's supported deployment flow to upload/deploy the project.
3. Make sure index.html is at the project root and keep the assets folder beside it.
4. Deploy. Vercel will provide a public *.vercel.app URL.
5. If your old deployment is paused, check your Vercel dashboard usage/account status before redeploying.

FREE HOSTING OPTION B — GitHub Pages
1. Sign in at https://github.com and create a new public repository.
2. Upload index.html and the assets folder (including wedding-melody.wav).
3. Open repository Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
5. Wait for the Pages URL shown there.

Important
- The date year was set to 2026 because the next 17 November is in 2026. Change the date in BOTH the visible event text and the JavaScript `weddingTime` value if needed.
- Confirm the venue spelling and map pin before sharing with guests.
- This is a static site and does not need a database or paid backend.
- Background music starts only after a visitor taps Play music, as required by mobile browser autoplay rules.
- The melody is an original synthesized instrumental placeholder, not a recording of a traditional song. You can replace assets/wedding-melody.wav with a licensed track, keeping the same filename and WAV format.
